# 🚀 TVBox 五合一终极聚合矩阵

本项目吸取了 GitHub 上 5 个顶级 TVBox 仓库的精华，打造了目前最强、最全自动的 TVBox 配置托管中心。

## 🌟 融合的五大黑科技

1. **`lubin776` 的深度解剖**：深入每一个 JSON 的毛细血管，把 `sites`、`lives` 和 `parses` 全部剥离提取。
2. **`niubihu1` 的广告门禁与内核优化**：拦截所有含“广告、发卡、福利”的垃圾源，并注入 `IJK` 高级解码参数，保证极速纯净。
3. **`fish2018` 的资产私有化 (核心亮点)**：**不再依赖别人的 `spider.jar`！** 脚本会自动把最新爬虫 JAR 包下载到本仓库的 `jar/` 目录下，并生成 MD5 防重复。彻底告别“上游删库导致全网失效”的痛点！
4. **`guxia66898` 的 L1/L2 深度验活与体检面板**：两层网络测速校验，并在 `output/dashboard.md` 中生成可视化的数据统计。
5. **`hebijunge` 的 Actions 自动化流水线**：每 12 小时全自动在云端完成上述所有动作，并自动推送 Commit，你只需躺平使用。

## 🛠️ 极简部署指南
1. 将所有文件推送到你的 GitHub 仓库。
2. 前往 **Settings -> Actions -> General -> Workflow permissions** 勾选 `Read and write permissions`。
3. 手动运行一次 Actions。
4. 运行成功后，你可以在 `output/` 文件夹里看到单仓、多仓以及体检报告。

**你的终极订阅链接（自带极速 CDN）：**
`https://ghfast.top/https://raw.githubusercontent.com/你的名字/你的仓库名/main/output/single_core.json`
