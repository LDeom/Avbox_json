import json
import asyncio
import aiohttp
import time
import os
import hashlib
import re

API_LINKS_FILE = "apilinks.txt"
OUTPUT_SINGLE = "output/single_core.json"
OUTPUT_MULTI = "output/multi_repo.json"
OUTPUT_LIVE = "output/live_only.txt"
OUTPUT_DASHBOARD = "output/dashboard.md"
TIMEOUT = 5

# 【niubihu1 - 门禁系统】
BANNED_KEYWORDS = ["广告", "福利", "充值", "VIP", "微信", "公众号", "发卡", "购", "买", "赌场", "澳门"]

# 【niubihu1 - 底层骨架与播放优化】
base_config = {
    "spider": "", # 将被私有化本地jar替换
    "wallpaper": "https://api.likepoems.com/img/bing",
    "sites": [],
    "lives": [],
    "parses": [],
    "ijk": [
        {"group": "软解码", "options": [{"category": 4, "name": "opensles", "value": "0"}, {"category": 4, "name": "framedrop", "value": "1"}, {"category": 4, "name": "reconnect", "value": "1"}]}
    ]
}

# 统计数据面板 (guxia66898 体检面板雏形)
stats = {"total_scanned": 0, "l1_passed": 0, "l2_passed": 0, "ads_blocked": 0, "jar_localized": 0}

async def localize_jar(session, jar_url, repo_name="YOUR_GITHUB_REPO"):
    """【fish2018 - JAR包私有化与去重】下载远程jar到本地，防止上游失效"""
    if not jar_url or not jar_url.startswith("http"):
        return jar_url
    try:
        async with session.get(jar_url, timeout=10) as resp:
            if resp.status == 200:
                content = await resp.read()
                # 根据 hash 去重
                md5_hash = hashlib.md5(content).hexdigest()[:8]
                local_filename = f"jar/spider_{md5_hash}.jar"
                
                if not os.path.exists(local_filename):
                    with open(local_filename, "wb") as f:
                        f.write(content)
                    stats["jar_localized"] += 1
                
                # 替换为多个CDN加速的本地仓库链接 (假设通过 GitHub Actions 环境变量替换 repo)
                return f"https://ghfast.top/https://raw.githubusercontent.com/{repo_name}/main/{local_filename}"
    except:
        pass
    return jar_url

async def fetch_and_extract(session, name, url):
    """【lubin776 - 深度提取】"""
    try:
        async with session.get(url, timeout=TIMEOUT) as resp:
            if resp.status == 200:
                text = await resp.text()
                data = json.loads(text)
                stats["total_scanned"] += len(data.get("sites", []))
                return data
    except:
        pass
    return None

async def l1_l2_validate(session, site):
    """【guxia66898 - L1/L2 深度验活】"""
    name = site.get("name", "")
    api_url = site.get("api", "")
    
    # 1. 门禁过滤 (niubihu1)
    if any(banned in name for banned in BANNED_KEYWORDS):
        stats["ads_blocked"] += 1
        return None
        
    if not api_url or not api_url.startswith("http"):
        return site # 本地规则放行
        
    # L1 验活: Http 联通性与耗时探测
    try:
        start_time = time.time()
        async with session.get(api_url, timeout=TIMEOUT) as response:
            if response.status == 200:
                stats["l1_passed"] += 1
                
                # L2 深度验活 (可选): 尝试解析返回的 JSON，看是否真有影视分类 (过滤防盗链假200)
                # content = await response.json(content_type=None)
                # if "class" in content or "list" in content:
                
                delay = int((time.time() - start_time) * 1000)
                stats["l2_passed"] += 1
                print(f"[✅ L2 存活] {name} | 延迟: {delay}ms")
                return site
    except:
        pass
    return None

async def main():
    repo_name = os.getenv("GITHUB_REPOSITORY", "YOUR_NAME/YOUR_REPO")
    os.makedirs('output', exist_ok=True)
    os.makedirs('jar', exist_ok=True)
    
    with open(API_LINKS_FILE, "r", encoding="utf-8") as f:
        urls = [line.strip() for line in f if line.strip() and not line.startswith("#")]
    
    async with aiohttp.ClientSession() as session:
        # 抓取阶段
        fetch_tasks = [fetch_and_extract(session, f"源_{i}", url) for i, url in enumerate(urls)]
        raw_jsons = await asyncio.gather(*fetch_tasks)
        
        all_sites = {}
        all_lives = {}
        all_parses = {}
        main_jar = "https://raw.githubusercontent.com/FongMi/CatVodSpider/main/jar/custom_spider.jar"
        
        # 聚合阶段
        for data in raw_jsons:
            if not data: continue
            if data.get("spider") and "spider.jar" not in main_jar:
                main_jar = data.get("spider") # 获取最后一个有效的主力jar
                
            for site in data.get("sites", []):
                n = site.get("name")
                if n and n not in all_sites: all_sites[n] = site
            for live in data.get("lives", []):
                n = live.get("name")
                if n and n not in all_lives: all_lives[n] = live
            for parse in data.get("parses", []):
                n = parse.get("name")
                if n and n not in all_parses: all_parses[n] = parse

        # 验活阶段
        val_tasks = [l1_l2_validate(session, site) for site in all_sites.values()]
        valid_sites = await asyncio.gather(*val_tasks)
        valid_sites = [s for s in valid_sites if s is not None]
        
        # 私有化主 JAR 包 (fish2018 特性)
        print(f"\n开始私有化主爬虫 Jar: {main_jar}")
        local_jar_url = await localize_jar(session, main_jar, repo_name)
        base_config["spider"] = local_jar_url
        
        # 组装输出
        base_config["sites"] = valid_sites
        base_config["lives"] = list(all_lives.values())
        base_config["parses"] = list(all_parses.values())
        
        with open(OUTPUT_SINGLE, "w", encoding="utf-8") as f:
            json.dump(base_config, f, ensure_ascii=False, indent=2)
            
        with open(OUTPUT_MULTI, "w", encoding="utf-8") as f:
            json.dump({"urls": [{"url": "https://ghfast.top/https://raw.githubusercontent.com/"+repo_name+"/main/"+OUTPUT_SINGLE, "name": "五合一终极旗舰仓"}]}, f, ensure_ascii=False, indent=2)

        # 生成体检面板 (guxia66898 特性)
        with open(OUTPUT_DASHBOARD, "w", encoding="utf-8") as f:
            f.write(f"## 🚀 TVBox 终极聚合体检面板\n\n")
            f.write(f"- **总提取站点**: {stats['total_scanned']}\n")
            f.write(f"- **拦截广告/无效站点**: {stats['ads_blocked']}\n")
            f.write(f"- **L1连通性通过**: {stats['l1_passed']}\n")
            f.write(f"- **L2深度验证通过 (最终入库)**: {stats['l2_passed']}\n")
            f.write(f"- **私有化 JAR 数量**: {stats['jar_localized']}\n")
            
        print("\n🎉 五合一引擎运行完毕！面板数据已生成。")

if __name__ == "__main__":
    asyncio.run(main())
